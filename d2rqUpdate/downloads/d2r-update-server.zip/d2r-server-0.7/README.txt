D2R Server is a Linked Data server and SPARQL endpoint for relational databases.

Check doc/index.html for more information, or visit the website at

    http://www4.wiwiss.fu-berlin.de/bizer/d2r-server/

for the latest updates.